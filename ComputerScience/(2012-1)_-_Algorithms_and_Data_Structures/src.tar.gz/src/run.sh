g++ Tarea\ 01.cpp Tools/*.cpp -o tarea1
echo complilacion terminada!
