/*
 * Options.cpp
 *
 *  Created on: Apr 4, 2012
 *      Author: kynku
 */

#include "Options.h"
#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

using namespace std;

Options::Options() {
	this->conjetura = 1;
	this->max = 0;
	this->verbose = true;
}
Options::Options(int argc, char **argv) {
	bool pass1 = false, pass2 = false;
	for (int i = 0; i < argc; ++i) {
		if (strcmp(argv[i], "-n") == 0) {
			this->max = atoi(argv[++i]);
			if (this->max == 0) {
				cout << "ERROR!!! Parametro -n invalido!!!" << endl;
				abort();
			}
			pass1 = true;
		}
		if (strcmp(argv[i], "--conjetura") == 0) {
			this->conjetura = atoi(argv[++i]);
			if (conjetura == 0) {
				cout << "ERROR!!! Parametro --conjetura invalido!!!" << endl;
				abort();
			}
			pass2 = true;
		}
		if (strcmp(argv[i], "-v") == 0) {
			this->verbose = true;
		}
	}
	if (!pass1 || !pass2){
		cout << "ERROR!!! Muy pocos parametros!!!" << endl;
		abort();
	}
}

Options::~Options() {
}

