/*
 * Options.h
 *
 *  Created on: Apr 4, 2012
 *      Author: kynku
 */

#ifndef OPTIONS_H_
#define OPTIONS_H_
class Options {
public:
	int conjetura;
	bool verbose;
	long max;
	Options(int argc, char **argv);
	Options();
	virtual ~Options();
    long getMax() const;
};

#endif /* OPTIONS_H_ */
